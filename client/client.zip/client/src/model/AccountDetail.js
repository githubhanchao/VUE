/**
 * Created by huangjason on 2017/9/15.
 */

export default {
  create() {
    return {
      createDate: '',     // 创建时间
      orderNo: '',     // 商户订单号
      tradeNo: '',     // 流水号
      type: '',     // 类型
      debitAmount: '',     // 收入
      creditAmount: '',     // 支出
      balance: '',     // 账户余额
      summary: '',     // 摘要
    };
  },
};
