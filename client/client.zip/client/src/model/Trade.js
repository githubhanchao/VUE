/**
 * Created by huangjason on 2017/9/15.
 */

export default {
  create() {
    return {
      createDate: '',     // 创建时间
      productName: '',     // 商品名称
      orderNum: '',     // 商户订单号
      platfromTradeId: '',     // 平台交易号
      payway: '',           // 支付方式
      fee: '',            // 手续费
      amout: '',          // 金额
      status: '',         // 状态
    };
  },
};
