const PAY_CODE = '在线支付';
const AGENTPAY_CODE = '代付';

module.exports = {
  PAY_CODE,
  AGENTPAY_CODE,
};
