
import * as actions from './actions';
import * as mutations from './mutations';

const state = {

};

const getters = {

};

const user = {
  state,
  actions,
  mutations,
  getters,
};

export default user;
