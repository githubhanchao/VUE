/**
 * Created by huangjason on 2017/7/13.
 */

const AUTH_TOKEN = 'auth_token';
const ACCESS_TOKEN = 'access-token';
const OPERATOR_NAME = 'operator_name';
const SEARCH_STATUS = 'search_status';
const GUIDE_STATUS = 'guide_status';

module.exports = {
  AUTH_TOKEN,
  ACCESS_TOKEN,
  OPERATOR_NAME,
  SEARCH_STATUS,
  GUIDE_STATUS,
};

