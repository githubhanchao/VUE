
import * as actions from './actions';
import * as mutations from './mutations';

const state = {

};

const account = {
  state,
  actions,
  mutations,
};

export default account;
