const OUT = 'out';
const IN = 'in';

module.exports = {
  OUT,
  IN,
};
