
module.exports = {
  ACTIVE: 'active',
  ACTIVE_PHONE_NO: 'activePhoneNo',
  ACTIVE_LOGIN_PWD: 'activeLoginPwd',
  ACTIVE_TRADE_PWD: 'activeTradePwd',
};
