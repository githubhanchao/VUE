import * as actions from './actions';
import * as mutations from './mutations';

const state = {

};

const notification = {
  state,
  actions,
  mutations,
};

export default notification;
