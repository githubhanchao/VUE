/**
 * Created by huangjason on 2017/9/25.
 */
const CAPTCHA = 'captcha';
const TARDE_PWD = 'tradePassword';
const CHECK_TRADE_PWD = 'tradePassword';
const SECURITY_QUESTION = 'securityQuestion';


module.exports = {
  CAPTCHA,
  TARDE_PWD,
  CHECK_TRADE_PWD,
  SECURITY_QUESTION,
};
