/**
 * Created by huangjason on 2017/7/13.
 */
// 登录状态

const INIT = 1;                 // 初始状态
const VALIDATING = 2;           // 验证中


module.exports = {
  INIT,
  VALIDATING,
};

