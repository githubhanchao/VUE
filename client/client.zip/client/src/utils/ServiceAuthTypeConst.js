/**
 * Created by huangjason on 2017/7/13.
 */

const SMS = 'sms';
const EMAIL = 'email';
const WORD = 'word';

module.exports = {
  SMS,
  EMAIL,
  WORD,
};

