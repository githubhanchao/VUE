
import { install } from './install';

export default class VuePermission {
}

VuePermission.version = '__VERSION__';
VuePermission.install = install;
