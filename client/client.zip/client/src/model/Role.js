/**
 * Created by huangjason on 2017/9/15.
 */

export default {
  create() {
    return {
      roleName: '',     // 角色名称
      roleStatus: '',   // 角色状态；normal - 正常， close - 关闭
      customerId: '',
    };
  },
};
