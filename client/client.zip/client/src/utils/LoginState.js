/**
 * Created by huangjason on 2017/7/13.
 */
// 登录状态

const LOGIN_INIT = 1;           // 初始状态
const LOGINING = 2;             // 登录中


module.exports = {
  LOGIN_INIT,
  LOGINING,
};

