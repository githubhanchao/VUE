/**
 * Created by huangjason on 2017/9/15.
 */

// 公告
export default {
  create() {
    return {
      phone_no: '',     // 手机号码
    };
  },
};
