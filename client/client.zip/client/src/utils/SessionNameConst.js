/**
 * Created by huangjason on 2017/9/25.
 */
const RETRIEVE_PWD = 'retrievePwd';
const LOGIN = 'login';
const TRADE_PASSWORD = 'tradePwd';
const ACTIVE = 'active';
const CREATE_SECURITY_KEY = 'createSecurityKey';
const UPDATE_SECURITY_KEY = 'updateSecurityKey';
const DELETE_SECURITY_KEY = 'delSecurityKey';
const CHECK_SECURITY_KEY = 'checkSecurityKey';

module.exports = {
  RETRIEVE_PWD,
  LOGIN,
  TRADE_PASSWORD,
  ACTIVE,
  CREATE_SECURITY_KEY,
  UPDATE_SECURITY_KEY,
  DELETE_SECURITY_KEY,
  CHECK_SECURITY_KEY,
};
