/**
 * Created by huangjason on 2017/9/25.
 */
const MODIFY_LOGIN_PWD = 'login_pass';
const MODIFY_TRADE_PWD = 'pay_pass';
const BIND_MOBILE = 'bind_mobile';
const IDENTITY_WORD = 'google_authen';

module.exports = {
  MODIFY_LOGIN_PWD,
  MODIFY_TRADE_PWD,
  BIND_MOBILE,
  IDENTITY_WORD,
};
