/**
 * Created by huangjason on 2017/9/18.
 */

const LOGIN_HINT = {
  ACCOUNT_NOT_BE_NULL: '账户不能为空',
  PASSWORD_NOT_BE_NULL: '密码不能为空',
  CAPTCHA_NOT_BE_NULL: '验证码不能为空',
};


module.exports = {
  LOGIN_HINT,
};
