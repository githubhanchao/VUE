/**
 * Created by alex on 2017/9/24.
 */
import store from '../vuex/store';
import ActionTypeName from '../utils/ActionTypeName';

// https://zh.wikipedia.org/wiki/%E5%8D%95%E4%B8%80%E5%8A%9F%E8%83%BD%E5%8E%9F%E5%88%99
// 违反面向对象设计原则的SCP原则，强烈建议改动，不要找到任何点去 填充大量逻辑代码

export default (to) => true;
